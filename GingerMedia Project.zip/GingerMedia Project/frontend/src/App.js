import React, { useState } from 'react'
import Login from './Login'
import { RouterProvider, createBrowserRouter } from 'react-router-dom'
import Main from './Main'
import SignUp from './SignUp'
import Profile from './Profile'
import MyContext from './MyContext'


const App = () => {

  const [value, setValue] = useState('');

  const myRouter=createBrowserRouter([
    { 
      path:'/',
      element:<Main/>
    },
    { 
      path:'/login',
      element:<Login/>
    },
    { 
      path:'/signup',
      element:<SignUp/>
    },
    { 
      path:'/profile',
      element:<Profile/>
    }


  ])

  return (
    <MyContext.Provider value={{ value, setValue }}>
    <RouterProvider router={myRouter}>
    <div>
    
    </div>
    </RouterProvider>
    </MyContext.Provider>
  )
}

export default App