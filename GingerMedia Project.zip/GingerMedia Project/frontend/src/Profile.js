import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import MyContext from './MyContext';

const Profile = () => {
  const { value } = useContext(MyContext);
  const [userData, setUserData] = useState(null);
  const [filterValue, setFilterValue] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [updatedData, setUpdatedData] = useState({});

  useEffect(() => {
    axios.get('http://localhost:8081/login')
      .then(response => {
        setUserData(response.data);
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
      });
  }, []);

  useEffect(() => {
    if (userData) {
      const newData = userData.find(dt => dt.email === value);
      setFilterValue(newData);
      console.log(newData);
    }
  }, [userData, value]);

  const handleEdit = () => {
    setEditMode(true);
    // Populate updated data with current user data
    setUpdatedData({ ...filterValue });
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedData(prevState => ({
      ...prevState,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.put(`http://localhost:8081/login/${filterValue.id}`, updatedData)
      .then(response => {
        console.log(response.data);
        // Refresh user data after update
        axios.get('http://localhost:8081/login')
          .then(response => {
            setUserData(response.data);
          })
          .catch(error => {
            console.error('Error fetching user data:', error);
          });
        setEditMode(false);
      })
      .catch(error => {
        console.error('Error updating user data:', error);
      });
  };

  return (
    <div className='flex justify-center items-center bg-blue-500 h-screen'>
      <div className='bg-white p-3 rounded-md shadow-lg w-96'>
        <div className='flex justify-between'><h1 className='text-2xl font-semibold mb-4 ml-[30%] '>User Profile</h1>  <button className='mr-2 px-3 rounded-lg bg-green-500' onClick={handleEdit}>Edit</button></div>
        {filterValue ? (
          <>
            {editMode ? (
              <form className=' ' onSubmit={handleSubmit}>
                <div className='mb-3'>
                  <label className='font-medium'>Name:</label>
                  <input  className=' px-2 ml-4 m-2 p-1 outline ' type='text' name='name' value={updatedData.name} onChange={handleChange} />
                </div>
                <div className='mb-3'>
                  <label className='font-medium'>Email:</label>
                  <input  className=' px-2 ml-4 m-2 p-1 outline ' type='email' name='email' value={updatedData.email} onChange={handleChange} />
                </div>

                   <div className='mb-3'>
                  <label className='font-medium'>Contact:</label>
                  <input  className=' px-2 ml-4 m-2 p-1 outline ' type='number' name='contact' value={updatedData.contact} onChange={handleChange} />
                </div>

                <div className='mb-3'>
                  <label className='font-medium'>Age:</label>
                  <input  className=' px-2 ml-4 m-2 p-1 outline ' type='number' name='age' value={updatedData.age} onChange={handleChange} />
                </div>
                <div className='mb-3'>
                 <label className='font-medium'>DOB:</label>
                 <input  className=' px-2 ml-4 m-2 p-1 outline ' type='text' name='dob' value={updatedData.dob} onChange={handleChange} />
                </div>
                <div className='mb-3'>
                <label className='font-medium'>Address:</label>
                <input  className=' px-2 ml-4 m-2 p-1 outline ' type='text' name='address' value={updatedData.address} onChange={handleChange} />
               </div>
                <button className='w-full my-2 bg-green-500 p-2 rounded-lg ' type='submit'>Save</button>
              </form>
            ) : (
              <>
              <div  className='pl-10'>
                <div className='mb-3'>
                  <label className='font-medium'>Name:</label>
                  <p className='text-gray-800'>{filterValue.name}</p>
                </div>
                <div className='mb-3'>
                  <label className='font-medium'>Email:</label>
                  <p className='text-gray-800'>{filterValue.email}</p>
                </div>
                   
                <div className='mb-3'>
              <label className='font-medium'>Contact:</label>
              <p className='text-gray-800'>{filterValue.contact}</p>
            </div>
            <div className='mb-3'>
              <label className='font-medium'>Age:</label>
              <p className='text-gray-800'>{filterValue.age}</p>
            </div>
            <div className='mb-3'>
              <label className='font-medium'>DOB:</label>
              <p className='text-gray-800'>{filterValue.dob}</p>
            </div>
            <div className='mb-3'>
              <label className='font-medium'>Address:</label>
              <p className='text-gray-800'>{filterValue.address}</p>
            </div>
            </div>

                
              </>
            )}
          </>
        ) : (
          <p>Loading...</p>
        )}
      </div>
    </div>
  );
}

export default Profile;
