export function validation(values){
  
    let error={};
    const emailPattern=/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    const passwordPattern= /^[a-zA-Z0-9!@#$%^&*]{6,16}$/;

    if(values.name==="")
      error.name="Name should not be empty";
    else
      error.name=""

    if(values.email==="")
     error.email="Email should not be empty";
    else if(!emailPattern.test(values.email))
      error.email="Enter valid Email"
    else
      error.email=""

    if(values.password==="")
       error.password="Password should not be empty"  
    else if(!passwordPattern.test(values.password))
       error.password="Enter Valid Password "
     else
       error.password=""

      return error; 
}