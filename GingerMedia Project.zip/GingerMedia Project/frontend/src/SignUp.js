import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { validation } from './Validation';
import axios from 'axios';

const SignUp = () => {
    const [errors, setErrors] = useState({});
    const [values, setValues] = useState({
        name: '',
        email: '',
        password: ''
    });

    const navigate = useNavigate();

    function handleSubmit(e) {
        e.preventDefault();
        setErrors(validation(values));
        if (Object.keys(errors).length === 0) {
            axios.post('http://localhost:8081/signup', values)
                .then(res => {
                    navigate('/login');
                })
                .catch(err => console.log(err));
        }
    }

    function handleInput(e) {
        setValues(prev => ({ ...prev, [e.target.name]: e.target.value }));
    }

    return (
        <div className='flex justify-center items-center bg-blue-500 h-screen'>
            <div className='bg-white p-3 rounded-md shadow-lg'>

                <form onSubmit={handleSubmit} className='m-6' action="">
                    <div className='mb-3'>
                        <label className='font-medium' htmlFor='name'>Name</label><br />
                        <input onChange={handleInput} className='border rounded-md p-2 w-full shadow-md' name='name' type='text' placeholder="Enter Name" />
                        <p className='text-sm text-red-500 w-full'> {errors.name && errors.name} </p>

                    </div>
                    <div className='mb-3'>
                        <label className='font-medium' htmlFor='email'>Email</label><br />
                        <input onChange={handleInput} className='border rounded-md p-2 w-full shadow-md' type="email" name='email' placeholder="Enter Email" />
                        <p className='text-sm text-red-500 w-full'> {errors.email && errors.email} </p>
                    </div>
                    <div className='mb-3'>
                        <label className='font-medium' htmlFor='password'>Password</label><br />
                        <input onChange={handleInput} className='rounded-md border p-2 w-full shadow-md' type="password" name='password' placeholder="Enter Password" />
                        <p className='text-sm text-red-500 w-full'> {errors.password && errors.password} </p>
                    </div>
                    <button className='w-full text-white p-2 mt-4 rounded-md bg-green-500'>Sign up</button>

                    <p className='text-sm mt-1'>Are you agree to our terms and policies?</p>

                    <Link to='/login'><button className='w-full mt-4 rounded-md p-2 border'>Login</button></Link>

                </form>
            </div>
        </div>
    );
};

export default SignUp;
